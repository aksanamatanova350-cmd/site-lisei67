// Простейшая логика: мобильное меню и обработка формы (клиентская)
document.addEventListener('DOMContentLoaded', function () {
  // Навигация (мобильная)
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const expanded = toggle.getAttribute('aria-expanded') === 'true';
      toggle.setAttribute('aria-expanded', String(!expanded));
      nav.classList.toggle('open');
    });
  }

  // Форма обратной связи: локальная валидация и демонстрация отправки
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.trim();
      const message = document.getElementById('message').value.trim();
      const status = document.getElementById('formStatus');

      if (!name || !email || !message) {
        status.style.color = 'crimson';
        status.textContent = 'Пожалуйста, заполните все поля.';
        return;
      }

      // Демонстрация: здесь можно отправить fetch() на серверный endpoint
      console.log('Сообщение формы:', { name, email, message });

      status.style.color = 'green';
      status.textContent = 'Спасибо! Ваше сообщение отправлено (демо).';
      form.reset();
    });
  }
});